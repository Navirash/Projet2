const Home = window.httpVueLoader('./components/Home.vue')
const Connect = window.httpVueLoader('./components/Connect.vue')
const Register = window.httpVueLoader('./components/Register.vue')
const Kisomnous = window.httpVueLoader('./components/Kisomnous.vue')
const FAQ = window.httpVueLoader('./components/FAQ.vue')


const routes = [
  { path: '/', component: Home },
  { path: '/connect', component: Connect},
  { path: '/register', component:Register},
  { path: '/kisomnous', component: Kisomnous},
  { path: '/faq', component: FAQ},
]

const router = new VueRouter({
  routes
})

var app = new Vue({
  router,
  el: '#app',
  data: {
    test : [],
    listId : [],
    recettesCourantes : [],
    userId : 0,
  },
  async mounted () {
  },
  methods: {
    async testfunction(ingredients){
      this.listId = []
      this.recettesCourantes = []
      let ch = ""
      let space = 0
      for(let i=0; i<ingredients.length; i++){
        if(ingredients[i]==" " && space<1){
          space = space + 1
        }
        else if(ingredients[i] == ","){
          ch = ch + ',+'
          space = 0
        }
        else{
          ch = ch + ingredients[i]
        }
      }
      const res = await axios.get('/api/recipes/' + ch);
      this.test = res.data;
      for(let i=0; i<this.test.length; i++){
        let tab = []
        let tab2 = []
        let tabUsed = []
        let tabTemp = []
        for(let j=0; j<this.test[i].missedIngredients.length; j++){
          non = true
          let k = 0
          while(k<tab2.length && non==true){
            if (this.test[i].missedIngredients[j].id == tab2[k]){
              non = false
            }
            k++
          }
          if(non == true){
            
            tab2.push(this.test[i].missedIngredients[j].id)
            let object2 = {
              id_ingredients : this.test[i].missedIngredients[j].id,
              img_ingredients : this.test[i].missedIngredients[j].image,
              name_ingredients : this.test[i].missedIngredients[j].name,
            }
            tab.push(object2)

          }
        }

        for(let j=0; j<this.test[i].usedIngredients.length; j++){
          non = true
          let k = 0
          while(k<tabTemp.length && non==true){
            if (this.test[i].usedIngredients[j].id == tabTemp[k]){
              non = false
            }
            k++
          }
          if(non == true){
            tabTemp.push(this.test[i].usedIngredients[j].id)
            let object2 = {
              id_ingredients : this.test[i].usedIngredients[j].id,
              img_ingredients : this.test[i].usedIngredients[j].image,
              name_ingredients : this.test[i].usedIngredients[j].name,
            }
            tabUsed.push(object2)

          }
        }
        const res2 = await axios.get('/api/informations/' + this.test[i].id);
        let object = {
          id_recipe : this.test[i].id,
          img_recipe : this.test[i].image,
          name_recipe : this.test[i].title,
          missed_ingredients : tab,
          used_ingredients : tabUsed,
          url : res2.data.url,
          diets : res2.data.diets,
          likes : this.test[i].likes,
        }
        this.listId.push(object)
      }
      for(let i=0; i<5; i++){
        this.recettesCourantes.push(this.listId[i])
      }
    },

    async inscription(email, mdp){
      const res = await axios.post('/api/register', {email : email, mdp : mdp});
    },
    async connexion(email, mdp){
      const res = await axios.post('/api/login', {email : email, password : mdp});
    },
    changefirstpage(){
      this.recettesCourantes = []
      for(let i=0; i<5; i++){
        this.recettesCourantes.push(this.listId[i])
      }
    },
    resetrecipes(){
      this.recettesCourantes = []
      this.test = []
      this.listId = []
    }
  }
})
