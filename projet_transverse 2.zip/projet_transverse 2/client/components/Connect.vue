<template>
    <div>
        <h2> CONNEXION </h2>
        <input v-model="email" type="email">
        <input v-model="password" type="password">
        <button @click="connexion(email, password)"> connect </button>

    </div>
</template>

<script>
module.exports = {
    data(){
        return{
            email : "",
            password : "",
        }
    },
    methods : {
        connexion(email, mdp){
            this.$emit("connexion", email, mdp);
        }
    }
}
</script>