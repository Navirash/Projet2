<template>
  <div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <label>Mettez la liste des ingrédients que vous avez séparés d'une virgule , </label>
    <input v-model="listIngredients">
    <button @click="testfunction(listIngredients)">click</button>
    <div v-if="onglet_courant==1"> 
      <article v-for="article in recettesCourantes" :key="article.id_recipe">
        <p> NOM DE LA RECETTE : {{article.name_recipe}} </p>
        <div class="recipe-img">
          <div :style="{ backgroundImage: 'url(' + article.img_recipe + ')' }" ></div>
        </div>
        <p> INGREDIENTS MANQUANTS : </p>
        <article v-for="kkk in article.missed_ingredients" :key="kkk.id">
        

          <div class="ingredient-img">
            <div :style="{ backgroundImage: 'url(' + kkk.img_ingredients + ')' }" ></div>
          </div>
          <p>{{kkk.name_ingredients}} </p>
          
        </article>

        <p> USED INGREDIENTS : </p>
        <article v-for="qqq in article.used_ingredients" :key="qqq.id">
        

          <div class="ingredient-img">
            <div :style="{ backgroundImage: 'url(' + qqq.img_ingredients + ')' }" ></div>
          </div>
          <p>{{qqq.name_ingredients}} </p>
          
        </article>


        <button @click="getinformations(article.id_recipe)"> CLICK source URL </button>
        <div v-if="itsTrue(article.id_recipe)==true">
          <p> <a v-bind:href="informations.url" > Lien vers la recette </a> </p>
          <article v-for="diet in informations.diets" :key="diet.id">
            <p> {{diet}} </p>
          </article>
        </div>
      </article>
    </div>


    <div v-else> 
      <article v-for="article in recettesCourantesbis" :key="article.id_recipe">
        <p> NOM DE LA RECETTE : {{article.name_recipe}} </p>
        <div class="recipe-img">
          <div :style="{ backgroundImage: 'url(' + article.img_recipe + ')' }" ></div>
        </div>
        <p> INGREDIENTS MANQUANTS : </p>
        <article v-for="kkk in article.missed_ingredients" :key="kkk.id">
        

          <div class="ingredient-img">
            <div :style="{ backgroundImage: 'url(' + kkk.img_ingredients + ')' }" ></div>
          </div>
          <p>{{kkk.name_ingredients}} </p>
          
        </article>

        <p> USED INGREDIENTS : </p>
        <article v-for="qqq in article.used_ingredients" :key="qqq.id">
        

          <div class="ingredient-img">
            <div :style="{ backgroundImage: 'url(' + qqq.img_ingredients + ')' }" ></div>
          </div>
          <p>{{qqq.name_ingredients}} </p>
          
        </article>

        <button @click="getinformations(article.id_recipe)"> CLICK INFORMATIONS </button>
        <div v-if="itsTrue(article.id_recipe)==true">
          <p> <a v-bind:href="informations.url" > Lien vers la recette </a> </p>
          <article v-for="diet in informations.diets" :key="diet.id">
            <p> {{diet}} </p>
          </article>
        </div>
      </article>
    </div>

    <div v-if="listId.length > 0">
      <p> {{onglet_courant}} / {{listId.length/5}} </p>
      <button @click="prec()">precedent</button>
      <button @click="suivant()">suivant</button>
    </div>
  </div>
</template>

<script>


module.exports = {
  props: {
    test : { type: Array, default: []},
    listId : { type: Array, default: []},
    recettesCourantes : { type: Array, default: []},
    informations : {type: Object},
  },
  data () {
    return {
      editingId : 0,
      listIngredients : "",
      countMissedIngredients : 0,
      onglet_courant : 1,
      recettesCourantesbis : [],
    }
  },
  async mounted () {
  },
  methods: {
    testfunction(ingredients){
      if(this.onglet_courant != 1){
        this.onglet_courant = 1
      }
      this.$emit('testfunction', ingredients)
    },
    getinformations(id){
      this.$emit("getinformations", id);
      this.editingId = id;
    },
    itsTrue(id){
      if(this.editingId == id){
        return true;
      }
    },
    prec(){
      if(this.onglet_courant > 1){
        this.onglet_courant = this.onglet_courant - 1
        this.actualiser()
      }
    },
    suivant(){
      if(this.onglet_courant < this.listId.length/5){
        this.onglet_courant = this.onglet_courant + 1
        this.actualiser()
      }
    },
    actualiser(){
      if(this.onglet_courant != 1){
          this.recettesCourantesbis = []
          for(let i=(this.onglet_courant-1)*5; i<this.onglet_courant*5; i++){
            this.recettesCourantesbis.push(this.listId[i])
          }
        }
      }
  }
}
</script>

<style scoped>

  .recipe-img div {
    margin: 10px auto;
    width: 312px;
    height: 231px;
    background-size: cover;
  }

  .ingredient-img div{
    margin: 5px auto;
    width: 150px;
    height: 100px;
    background-size: cover;
  }
</style>